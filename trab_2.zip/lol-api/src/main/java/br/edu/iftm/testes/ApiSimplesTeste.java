package br.edu.iftm.testes;

import java.io.IOException;

import org.json.JSONObject;

import br.edu.iftm.api.Api;
import br.edu.iftm.api.JsonParser;

public class ApiSimplesTeste {

	public static void main(String[] args) throws IOException {
		Api api = new Api("https://jsonplaceholder.typicode.com/todos/1");
		JSONObject item = JsonParser.parseToObject(api.executar());
		System.out.println(item.get("userId"));
	}

}
