package br.edu.iftm.testes;

import java.awt.Image;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import org.json.JSONObject;

import br.edu.iftm.api.Api;
import br.edu.iftm.api.JsonParser;

public class ApiLolTeste {

	public static void main(String[] args) throws IOException {
		final String token = "<digite-o-token-da-riot-aqui>";
		String nomePokemon = "charizard";
		String url = String.format("https://pokeapi.co/api/v2/pokemon/%s", nomePokemon);
		Api api = new Api(url);

		Map<String, String> cabecalhos = new HashMap<String, String>();
		cabecalhos.put("X-Riot-Token", token);

		JSONObject json = JsonParser.parseToObject(api.executar(cabecalhos));
		criarJanela(json);
	}

	private static void criarJanela(JSONObject json) throws MalformedURLException, IOException {
		//int fotoId = json.getInt("profileIconId");

		JFrame janela = new JFrame();

		JTextField campoNickname = new JTextField();
		campoNickname.setBounds(50, 150, 200, 30);

		JButton botao = new JButton("Pesquisar");
		botao.setBounds(260, 150, 100, 30);

		//JLabel icone = pegarIcone(fotoId);
		JLabel nickname = new JLabel("Nome: " + json.getString("name"));
		nickname.setBounds(50, 0, 200, 50);

		JLabel Peso = new JLabel("Peso: " + json.getInt("weight"));
		Peso.setBounds(50, 25, 200, 70);
		
		JLabel Altura = new JLabel("Altura: " + json.getInt("height"));
		Altura.setBounds(50, 50, 200, 70);
		
		JLabel ID = new JLabel("iD: " + json.getInt("id"));
		ID.setBounds(50, 75, 200, 70);
		
		JLabel isDefault = new JLabel("is_default: " + json.getBoolean("is_default"));
		isDefault.setBounds(50, 100, 200, 70);

		janela.add(nickname);
		janela.add(Peso);
		//janela.revalidate();
		//janela.repaint();
		janela.add(Altura);
		janela.add(ID);
		janela.add(isDefault);

		botao.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				
			}
		});

		janela.add(campoNickname);
		janela.add(botao);

		janela.setBounds(100, 100, 400, 600);
		janela.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		janela.setLayout(null);
		janela.setVisible(true);
	}

	private static JLabel pegarIcone(int fotoId) throws MalformedURLException, IOException {
		String fotoUrl = String.format("http://ddragon.leagueoflegends.com/cdn/10.13.1/img/profileicon/%d.png", fotoId);
		JLabel icone = new JLabel("");
		Image imagem = ImageIO.read(new URL(fotoUrl));
		int larguraImagem = imagem.getWidth(null);
		int alturaImagem = imagem.getHeight(null);
		icone.setIcon(new ImageIcon(imagem));
		icone.setBounds(50, 100, larguraImagem, alturaImagem);
		return icone;
	}

}
